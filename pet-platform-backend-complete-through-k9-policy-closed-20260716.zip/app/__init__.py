"""Pet platform backend application."""

"""HTTP API assembly."""

"""Transactional notification provider adapters."""

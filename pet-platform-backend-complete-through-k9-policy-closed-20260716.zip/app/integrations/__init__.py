"""External provider adapters."""

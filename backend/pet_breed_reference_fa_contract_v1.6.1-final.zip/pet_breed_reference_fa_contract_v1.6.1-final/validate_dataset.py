#!/usr/bin/env python3
import hashlib,json,pathlib,sys
from jsonschema import Draft202012Validator,FormatChecker
B=pathlib.Path(__file__).parent
def load(n): return json.loads((B/n).read_text(encoding='utf-8'))
errors=[]
ref=load('breed-reference.fa.json'); schema=load('breed-reference.schema.json'); varieties=load('breed-varieties.fa.json')['varieties']; sources=load('evidence-sources.json')['sources']; claims=load('breed-claims.fa.json')['claims']; guidance=load('care-guidance.fa.json')['guidance']; maps=load('registry-crosswalk.json')['mappings']; bundle=load('backend-import-bundle.fa.json'); manifest=load('release-manifest.json')
Draft202012Validator.check_schema(schema); Draft202012Validator.check_schema(load('backend-import-bundle.schema.json'))
schema_errors=[]
def check(instance,sch,label):
 for e in Draft202012Validator(sch,format_checker=FormatChecker()).iter_errors(instance): schema_errors.append(f'{label}:{e.json_path}:{e.message}')
check(ref,schema,'breed-reference'); check(bundle,load('backend-import-bundle.schema.json'),'backend-bundle')
for filename,key,defname in [('breed-varieties.fa.json','varieties','variety'),('evidence-sources.json','sources','source'),('breed-claims.fa.json','claims','claim'),('care-guidance.fa.json','guidance','guidance'),('registry-crosswalk.json','mappings','registryMapping')]:
 x=load(filename)
 check(x[key],{'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':schema['$defs'],'type':'array','items':{'$ref':f'#/$defs/{defname}'}},filename)
breed_ids={x['breed_id'] for x in ref['breeds']}; variety_ids={x['variety_id'] for x in varieties}; source_ids={x['source_id'] for x in sources}; claim_ids={x['claim_id'] for x in claims}; map_ids={x['registry_mapping_id'] for x in maps}; targets=breed_ids|variety_ids
ref_errors=[]
def unique(seq,key,label):
 vals=[x[key] for x in seq]; dup={v for v in vals if vals.count(v)>1}
 if dup: ref_errors.append(f'duplicate {label}: {sorted(dup)}')
for seq,key,label in [(ref['breeds'],'breed_id','breed'),(varieties,'variety_id','variety'),(sources,'source_id','source'),(claims,'claim_id','claim'),(guidance,'guidance_id','guidance'),(maps,'registry_mapping_id','mapping')]: unique(seq,key,label)
for c in claims:
 if c['breed_or_variety_id'] not in targets: ref_errors.append('orphan claim '+c['claim_id'])
 if not set(c['supporting_source_ids'])<=source_ids: ref_errors.append('orphan source '+c['claim_id'])
 if c['claim_type'] in {'adult_weight_reference','height_reference'} and c['comparison_allowed']: ref_errors.append('comparison unexpectedly allowed '+c['claim_id'])
 if c['app_eligible'] and c['veterinary_review_status']!='veterinary_approved': ref_errors.append('eligible unapproved claim '+c['claim_id'])
for g in guidance:
 if not set(g['supporting_claim_ids'])<=claim_ids: ref_errors.append('orphan guidance claim '+g['guidance_id'])
 if g['approval_independence']!='independent_from_claim_approval': ref_errors.append('guidance independence missing '+g['guidance_id'])
 if g['app_eligible'] and (g['review_status']!='veterinary_approved' or not g['veterinary_approval_id']): ref_errors.append('eligible guidance lacks independent approval '+g['guidance_id'])
bundle_breeds={x['id'] for x in bundle['breeds']}; bundle_vars={x['id']:x['breed_id'] for x in bundle['varieties']}
for c in bundle['claims']:
 if c['breed_id'] not in bundle_breeds: ref_errors.append('bundle orphan breed '+c['id'])
 if c['variety_id'] is not None and bundle_vars.get(c['variety_id'])!=c['breed_id']: ref_errors.append('bundle variety parent mismatch '+c['id'])
checksum_errors=[]
h=hashlib.sha256()
for n in ['breed-varieties.fa.json','evidence-sources.json','breed-claims.fa.json','care-guidance.fa.json','registry-crosswalk.json','evidence-grade-rubric.fa.json']: h.update((B/n).read_bytes())
if ref['release']['content_checksum']!='sha256:'+h.hexdigest(): checksum_errors.append('breed-reference content checksum mismatch')
files=manifest['files']; canonical=json.dumps(files,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
if manifest['release_checksum']!='sha256:'+hashlib.sha256(canonical).hexdigest(): checksum_errors.append('release checksum mismatch')
for f in files:
 p=B/f['filename']
 if not p.exists() or p.stat().st_size!=f['byte_length'] or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']: checksum_errors.append('manifest mismatch '+f['filename'])
status=not(schema_errors or ref_errors or checksum_errors)
report=f'''# گزارش اعتبارسنجی وصله قرارداد ۱٫۶٫۱\n\n- نتیجه JSON Schema Draft 2020-12: {'قبول' if not schema_errors else 'رد'}؛ اعتبارسنج `python-jsonschema Draft202012Validator` با کنترل format.\n- نتیجه ارجاعی: {'قبول' if not ref_errors else 'رد'}؛ شناسه‌ها، والد واریته، منابع ادعا، ارجاع راهنما، نگاشت بک‌اند و استقلال تأیید بررسی شد.\n- نتیجه checksum: {'قبول' if not checksum_errors else 'رد'}؛ SHA-256 فایل مرجع، فایل‌های مانیفست و checksum قطعی انتشار بررسی شد.\n- تاریخ و روش بررسی URL: ۲۰۲۶-۰۷-۱۶؛ بررسی انباشته ۱۵۰ نشانی با بازیابی صفحه رسمی FCI/CFA/TICA یا PubMed و کنترل دسترسی/قابلیت تفسیر.\n- وضعیت بازبینی علمی: `scientific_review_required`؛ روبریک رسمی اضافه شده، اما ادعاها هنوز تأیید علمی نهایی نشده‌اند.\n- وضعیت بازبینی دامپزشکی: `veterinary_review_required`؛ هویت بازبین می‌تواند محرمانه بماند، اما تصمیم قابل ممیزی ثبت نشده است.\n- وضعیت کاربرد در اپ: همه ادعاها و راهنماها `app_eligible=false`.\n- پروفایل: {len(ref['breeds'])}؛ واریته: {len(varieties)}؛ منبع: {len(sources)}؛ ادعا: {len(claims)}؛ راهنما: {len(guidance)}.\n\n## خطاهای Schema\n{json.dumps(schema_errors,ensure_ascii=False,indent=2)}\n\n## خطاهای ارجاعی\n{json.dumps(ref_errors,ensure_ascii=False,indent=2)}\n\n## خطاهای Checksum\n{json.dumps(checksum_errors,ensure_ascii=False,indent=2)}\n'''
(B/'VALIDATION_REPORT.fa.md').write_text(report,encoding='utf-8')
# Refresh the canonical manifest after writing the governed validation report.
governed=sorted(p.name for p in B.iterdir() if p.is_file() and p.name!='release-manifest.json')
files=[{'filename':n,'byte_length':(B/n).stat().st_size,'sha256':hashlib.sha256((B/n).read_bytes()).hexdigest()} for n in governed]
release_checksum='sha256:'+hashlib.sha256(json.dumps(files,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
(B/'release-manifest.json').write_text(json.dumps({'schema_version':'1.0.0','dataset_version':'1.6.1-contract-patch','canonicalization':'UTF-8 JSON; files array sorted by filename; object keys sorted; compact separators; release-manifest.json excluded to avoid self-reference','files':files,'release_checksum':release_checksum},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS' if status else 'FAIL','schema_result':'PASS' if not schema_errors else 'FAIL','referential_result':'PASS' if not ref_errors else 'FAIL','checksum_result':'PASS' if not checksum_errors else 'FAIL','errors':schema_errors+ref_errors+checksum_errors},ensure_ascii=False,indent=2)); sys.exit(0 if status else 1)
